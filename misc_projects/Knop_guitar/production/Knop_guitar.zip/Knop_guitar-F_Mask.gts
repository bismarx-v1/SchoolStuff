G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2026-03-10T19:18:27+01:00*
G04 #@! TF.ProjectId,Knop_guitar,4b6e6f70-5f67-4756-9974-61722e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2026-03-10 19:18:27*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.600000*%
%ADD11C,5.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X178998471Y-251328257D03*
D11*
X178998471Y-251328257D03*
G04 #@! TD*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X257601706Y-251328268D03*
D11*
X257601706Y-251328268D03*
G04 #@! TD*
M02*
